export const Banner = () => {
  return <div className="banner">
    <h1>banner</h1>
  </div>;
};
