export const Categories = () => {
  return <div className="Categories">
    <h1>Categories</h1>
  </div>;
};
