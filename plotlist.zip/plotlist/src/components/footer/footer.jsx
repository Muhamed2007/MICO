export const Footer = () => {
  return <div className="Footer">
    <h1>Footer</h1>
  </div>;
};
